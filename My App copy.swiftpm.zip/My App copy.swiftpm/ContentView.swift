import SwiftUI
import CoreLocation
import MapKit
import UserNotifications

// MARK: - Reminder Model
struct Reminder: Identifiable, Codable, Equatable {
    let id: UUID
    var task: String
    var address: String
    var latitude: Double
    var longitude: Double
    
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

// MARK: - Location & Reminder Manager
class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    private var monitoredReminders: [Reminder] = []
    @Published var reminders: [Reminder] = [] {
        didSet {
            saveReminders()
        }
    }
    
    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        loadReminders()
    }
    
    func requestAuthorization() {
        manager.requestWhenInUseAuthorization()
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }
    
    func addReminder(task: String, address: String) {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(address) { [weak self] placemarks, error in
            guard let placemark = placemarks?.first,
                  let location = placemark.location else {
                print("Failed to find location for address")
                return
            }
            
            let reminder = Reminder(id: UUID(), task: task, address: address, latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
            DispatchQueue.main.async {
                self?.reminders.append(reminder)
                self?.monitoredReminders.append(reminder)
                self?.manager.startUpdatingLocation()
            }
        }
    }
    
    func updateReminder(_ updated: Reminder) {
        if let index = reminders.firstIndex(where: { $0.id == updated.id }) {
            reminders[index] = updated
            monitoredReminders.append(updated)
            manager.startUpdatingLocation()
        }
    }
    
    func deleteReminder(_ reminder: Reminder) {
        reminders.removeAll { $0.id == reminder.id }
        monitoredReminders.removeAll { $0.id == reminder.id }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let current = locations.first else { return }
        
        for (index, reminder) in monitoredReminders.enumerated().reversed() {
            let target = CLLocation(latitude: reminder.latitude, longitude: reminder.longitude)
            let distance = current.distance(from: target)
            
            if distance < 100 {
                triggerReminder(reminder)
                monitoredReminders.remove(at: index)
            }
        }
    }
    
    private func triggerReminder(_ reminder: Reminder) {
        let content = UNMutableNotificationContent()
        content.title = "Location Reminder"
        content.body = reminder.task
        content.sound = .default
        
        let request = UNNotificationRequest(identifier: UUID().uuidString,
                                            content: content,
                                            trigger: nil)
        
        UNUserNotificationCenter.current().add(request)
    }
    
    // MARK: - Persistence
    private let storageKey = "reminders"
    
    private func saveReminders() {
        if let data = try? JSONEncoder().encode(reminders) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }
    
    private func loadReminders() {
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let saved = try? JSONDecoder().decode([Reminder].self, from: data) {
            reminders = saved
            monitoredReminders = saved
        }
    }
}

// MARK: - Map View
struct SimpleMapView: View {
    var coordinate: CLLocationCoordinate2D
    
    @State private var region: MKCoordinateRegion
    
    init(coordinate: CLLocationCoordinate2D) {
        self.coordinate = coordinate
        _region = State(initialValue: MKCoordinateRegion(
            center: coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        ))
    }
    
    var body: some View {
        Map(coordinateRegion: $region, annotationItems: [MapPinItem(coordinate: coordinate)]) { item in
            MapMarker(coordinate: item.coordinate, tint: .red)
        }
        .frame(height: 150)
        .cornerRadius(10)
    }
}

struct MapPinItem: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
}

// MARK: - Edit Reminder View
struct EditReminderView: View {
    @Binding var reminder: Reminder
    var onSave: (Reminder) -> Void
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            Form {
                TextField("Task", text: $reminder.task)
                TextField("Address", text: $reminder.address)
            }
            .navigationTitle("Edit Reminder")
            .navigationBarItems(trailing: Button("Save") {
                onSave(reminder)
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
}

// MARK: - Reminder List View
struct ReminderListView: View {
    @ObservedObject var locationManager: LocationManager
    @State private var selectedReminder: Reminder?
    @State private var showEditSheet = false
    
    var body: some View {
        List {
            ForEach(locationManager.reminders) { reminder in
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text(reminder.task)
                            .font(.headline)
                        Spacer()
                        Button("Edit") {
                            selectedReminder = reminder
                            showEditSheet = true
                        }
                        .padding(.trailing, 8)
                        Button(role: .destructive) {
                            locationManager.deleteReminder(reminder)
                        } label: {
                            Image(systemName: "trash")
                        }
                    }
                    
                    Text(reminder.address)
                        .font(.subheadline)
                    
                    SimpleMapView(coordinate: reminder.coordinate)
                }
                .padding(.vertical, 8)
            }
        }
        .navigationTitle("Your Reminders")
        .sheet(isPresented: $showEditSheet) {
            if let reminder = selectedReminder {
                var editableReminder = reminder
                EditReminderView(reminder: Binding(
                    get: { editableReminder },
                    set: { editableReminder = $0 }
                ), onSave: { updated in
                    locationManager.updateReminder(updated)
                })
            }
        }
    }
}

// MARK: - Main Content View
struct ContentView: View {
    @State private var task = ""
    @State private var address = ""
    @StateObject private var locationManager = LocationManager()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                TextField("Enter Task", text: $task)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                TextField("Enter Address", text: $address)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button("Add Reminder") {
                    locationManager.addReminder(task: task, address: address)
                    task = ""
                    address = ""
                }
                .buttonStyle(.borderedProminent)
                
                NavigationLink("View All Reminders") {
                    ReminderListView(locationManager: locationManager)
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Location Reminder")
            .onAppear {
                locationManager.requestAuthorization()
            }
        }
    }
}

// MARK: - App View Entry Point (no @main)
struct LocationReminderAppView: View {
    var body: some View {
        ContentView()
    }
}

